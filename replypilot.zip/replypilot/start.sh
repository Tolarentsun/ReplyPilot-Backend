#!/bin/bash
# ReplyPilot - Start Script

echo "🚀 Starting ReplyPilot..."
echo ""

cd "$(dirname "$0")/backend"

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
  echo "📦 Installing dependencies..."
  npm install
fi

echo "✅ Starting server on port 4000..."
echo "🌐 Open: http://localhost:4000"
echo ""
node server.js
