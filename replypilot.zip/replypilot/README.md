# ReplyPilot 🚀
**AI-Powered Review Intelligence for Local Businesses**

Turn customer reviews into revenue. ReplyPilot analyzes reviews, generates professional AI responses, and delivers actionable business insights — all in one platform.

---

## Features

- **AI Sentiment Analysis** — Every review scored and categorized automatically
- **One-Click AI Responses** — Professional, personalized responses generated instantly
- **Trend Analytics** — Monthly charts, rating distribution, keyword themes
- **AI Insights Reports** — Strategic recommendations powered by Claude AI
- **Multi-Platform** — Google, Yelp, Facebook reviews in one dashboard
- **Subscription Management** — Free, Pro ($49/mo), Business ($149/mo) tiers via Stripe

---

## Quick Start

### 1. Install & Run

```bash
cd backend
npm install
node server.js
```

Open http://localhost:4000

### 2. Environment Variables

Copy and edit `backend/.env`:

```env
PORT=4000
JWT_SECRET=your-random-secret-here

# Optional: Enable real AI responses
ANTHROPIC_API_KEY=sk-ant-...

# Optional: Enable Stripe payments  
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PRO_PRICE_ID=price_...
STRIPE_BUSINESS_PRICE_ID=price_...
```

> **Without API keys:** The app works in template mode — AI responses are still generated using smart templates. Add your Anthropic API key to enable full Claude-powered responses.

### 3. Create Your Account

1. Go to http://localhost:4000/register.html
2. Fill in your name, business name, and email
3. A set of demo reviews will be pre-loaded for you to explore
4. Navigate to Dashboard → Reviews to generate AI responses
5. Dashboard → AI Insights for a full analysis report

---

## Project Structure

```
replypilot/
├── backend/
│   ├── server.js           # Express app entry point
│   ├── package.json
│   ├── .env                # Environment variables
│   ├── db/
│   │   ├── database.js     # SQLite schema & connection
│   │   └── seedData.js     # Demo review data
│   ├── middleware/
│   │   └── auth.js         # JWT authentication
│   └── routes/
│       ├── auth.js         # Register, login, profile
│       ├── reviews.js      # CRUD + AI response generation
│       ├── subscriptions.js # Stripe plans & checkout
│       └── insights.js     # AI business insights
├── frontend/
│   ├── config.js           # API base URL & helpers
│   ├── index.html          # Landing/marketing page
│   ├── login.html          # Authentication
│   ├── register.html       # Account creation
│   └── dashboard.html      # Full app dashboard
└── start.sh                # Quick start script
```

---

## API Endpoints

### Auth
- `POST /api/auth/register` — Create account
- `POST /api/auth/login` — Login
- `GET /api/auth/me` — Current user (auth required)
- `PUT /api/auth/profile` — Update profile (auth required)

### Reviews
- `GET /api/reviews` — List reviews (filters: platform, sentiment, rating, sort)
- `POST /api/reviews` — Add review manually
- `GET /api/reviews/analytics` — Analytics data
- `POST /api/reviews/:id/generate-response` — Generate AI response
- `PUT /api/reviews/:id/respond` — Mark as responded
- `DELETE /api/reviews/:id` — Delete review

### Insights
- `POST /api/insights/generate` — Generate AI insights report

### Subscriptions
- `GET /api/subscriptions/plans` — List plans
- `GET /api/subscriptions/current` — Current subscription
- `POST /api/subscriptions/checkout` — Create Stripe checkout (or demo upgrade)
- `POST /api/subscriptions/cancel` — Cancel subscription
- `POST /api/subscriptions/webhook` — Stripe webhook

---

## Deployment

### Railway (Recommended)

1. Push to GitHub
2. Connect repo to Railway
3. Set environment variables in Railway dashboard
4. Railway detects Node.js automatically

### Vercel

1. Deploy backend as a serverless function or use Railway for backend
2. Deploy frontend HTML files to Vercel
3. Update `API_BASE` in `frontend/config.js`

### Environment for Production

```env
NODE_ENV=production
PORT=4000
JWT_SECRET=<long-random-string>
FRONTEND_URL=https://yourdomain.com
ANTHROPIC_API_KEY=sk-ant-...
STRIPE_SECRET_KEY=sk_live_...
```

---

## Adding Real API Keys

### Anthropic (AI Responses)
1. Get API key from https://console.anthropic.com
2. Add to `.env`: `ANTHROPIC_API_KEY=sk-ant-...`
3. Restart server — full Claude-powered responses enabled

### Stripe (Payments)
1. Create account at https://stripe.com
2. Create two products: "Pro" ($49/mo) and "Business" ($149/mo)
3. Copy the price IDs to `.env`
4. Set up webhook pointing to `/api/subscriptions/webhook`

---

## Tech Stack

- **Backend:** Node.js + Express + better-sqlite3
- **Auth:** JWT (jsonwebtoken) + bcryptjs
- **Payments:** Stripe
- **AI:** Anthropic Claude API (claude-sonnet-4)
- **Frontend:** Vanilla HTML/CSS/JS (zero frameworks, zero build step)
- **Database:** SQLite (no setup required, file-based)

---

Built with ❤️ using ReplyPilot framework
